# Privacy Screen

Complete Android project. Two ways to get an APK:

## A) Android Studio (on your computer)
1. Install Android Studio.
2. File > Open > choose this `PrivacyScreen` folder (not a sub-folder).
3. Wait for "Gradle sync" to finish (first time downloads a lot; needs internet).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK: app/build/outputs/apk/debug/app-debug.apk

## B) GitHub (no installs needed)
1. Create a free GitHub account and a new empty repository.
2. Upload everything in this folder (including the hidden `.github` folder).
3. Open the repo's Actions tab > "Build APK" > Run workflow (it also runs on every upload).
4. When it turns green, open the run and download `privacy-screen-apk` under Artifacts.
   It is a zip containing app-debug.apk.

## Install on phone
Copy the APK to the phone and open it (allow "install unknown apps" when asked).
Then open the app, grant "Display over other apps", and switch protection on.
