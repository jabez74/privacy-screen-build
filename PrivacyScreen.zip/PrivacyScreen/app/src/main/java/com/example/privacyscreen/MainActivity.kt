package com.example.privacyscreen

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val dark = isSystemInDarkTheme()
            val context = LocalContext.current
            val colors = when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
                    if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
                dark -> darkColorScheme()
                else -> lightColorScheme()
            }
            MaterialTheme(colorScheme = colors) {
                PrivacyScreenApp()
            }
        }
    }
}

private fun serviceIntent(context: Context) = Intent(context, PrivacyOverlayService::class.java)

@Composable
private fun PrivacyScreenApp() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasOverlayPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var isRunning by remember { mutableStateOf(PrivacyPrefs.isRunning(context)) }
    var errorMessage by remember { mutableStateOf(PrivacyPrefs.error(context)) }
    var startAngle by remember { mutableFloatStateOf(PrivacyPrefs.startAngle(context)) }
    var maxAngle by remember { mutableFloatStateOf(PrivacyPrefs.maxAngle(context)) }

    // Re-check permission + service state whenever the user returns (e.g. from Settings).
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasOverlayPermission = Settings.canDrawOverlays(context)
                isRunning = PrivacyPrefs.isRunning(context)
                errorMessage = PrivacyPrefs.error(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Live updates from the service (started, stopped, or failed).
    DisposableEffect(Unit) {
        val prefs = PrivacyPrefs.prefs(context)
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == PrivacyPrefs.KEY_RUNNING || key == PrivacyPrefs.KEY_ERROR) {
                isRunning = PrivacyPrefs.isRunning(context)
                errorMessage = PrivacyPrefs.error(context)
            }
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    fun startService() {
        PrivacyPrefs.setError(context, null)
        errorMessage = null
        ContextCompat.startForegroundService(context, serviceIntent(context))
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        // The service runs either way; denial only hides the notification.
        startService()
    }

    fun setEnabled(enabled: Boolean) {
        if (!enabled) {
            context.stopService(serviceIntent(context))
            return
        }
        if (!hasOverlayPermission) return
        val needsNotificationPermission =
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(
                    context, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
        if (needsNotificationPermission) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startService()
        }
    }

    Scaffold(modifier = Modifier.fillMaxSize()) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "Privacy Screen",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Darkens your display when the phone is tilted away from you, so people beside you can't read it.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // ---- Permission card
            if (!hasOverlayPermission) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "Permission required",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            "Allow \"Display over other apps\" so the privacy tint can appear on top of any screen.",
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Button(
                            onClick = {
                                context.startActivity(
                                    Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Grant permission") }
                    }
                }
            }

            // ---- Error card (e.g. missing sensors)
            errorMessage?.let { message ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Text(
                        message,
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }

            // ---- Toggle card
            Card {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Privacy protection", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (isRunning) "Active" else "Off",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = isRunning,
                        enabled = hasOverlayPermission || isRunning,
                        onCheckedChange = { setEnabled(it) }
                    )
                }
            }

            // ---- Sensitivity card
            Card {
                Column(Modifier.padding(16.dp)) {
                    Text("Sensitivity", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(12.dp))

                    Text("Start tint angle: ${startAngle.roundToInt()}°")
                    Slider(
                        value = startAngle,
                        onValueChange = {
                            startAngle = it.roundToInt().toFloat()
                            if (maxAngle < startAngle + PrivacyPrefs.MIN_ANGLE_GAP) {
                                maxAngle = startAngle + PrivacyPrefs.MIN_ANGLE_GAP
                            }
                        },
                        onValueChangeFinished = {
                            PrivacyPrefs.setAngles(context, startAngle, maxAngle)
                        },
                        valueRange = 5f..60f
                    )

                    Text("Maximum blackout angle: ${maxAngle.roundToInt()}°")
                    Slider(
                        value = maxAngle,
                        onValueChange = {
                            maxAngle = maxOf(
                                it.roundToInt().toFloat(),
                                startAngle + PrivacyPrefs.MIN_ANGLE_GAP
                            )
                        },
                        onValueChangeFinished = {
                            PrivacyPrefs.setAngles(context, startAngle, maxAngle)
                        },
                        valueRange = 10f..85f
                    )

                    Text(
                        "Clear up to ${startAngle.roundToInt()}°, gradually darker until ${maxAngle.roundToInt()}°, near-black beyond that. Changes apply instantly.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            startAngle = PrivacyPrefs.DEFAULT_START_ANGLE
                            maxAngle = PrivacyPrefs.DEFAULT_MAX_ANGLE
                            PrivacyPrefs.setAngles(context, startAngle, maxAngle)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Reset to defaults (15° / 40°)") }
                }
            }

            // ---- Calibration card
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Straight-on position", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "0° means the phone held upright. If you normally hold it at a comfortable angle, hold it that way and tap below so that becomes your \"clear\" position.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(
                        enabled = isRunning,
                        onClick = {
                            context.startService(
                                serviceIntent(context).setAction(PrivacyOverlayService.ACTION_CALIBRATE)
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Use my current angle") }
                    OutlinedButton(
                        onClick = { PrivacyPrefs.setBaseline(context, 0f, 0f) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Reset to upright (0°)") }
                }
            }
        }
    }
}
