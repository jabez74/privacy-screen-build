package com.example.privacyscreen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max

/** Pure math, kept separate so it can be unit-tested. */
object TiltMath {
    const val TINT_ALPHA_AT_MAX = 0.95f
    const val BLACKOUT_ALPHA = 0.98f // never fully 1.0 so the user can still see to tilt back

    /**
     * tilt <= start        -> 0.0 (clear)
     * start < tilt < max   -> linear 0.0 .. 0.95
     * tilt >= max          -> 0.98
     */
    fun alphaFor(tiltDegrees: Float, start: Float, max: Float): Float = when {
        tiltDegrees <= start -> 0f
        tiltDegrees >= max -> BLACKOUT_ALPHA
        else -> TINT_ALPHA_AT_MAX * (tiltDegrees - start) / (max - start)
    }

    /** Smallest signed difference a - b, normalised to [-180, 180]. */
    fun angleDelta(a: Float, b: Float): Float {
        var d = (a - b) % 360f
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        return d
    }
}

class PrivacyOverlayService :
    Service(),
    SensorEventListener,
    SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var sensorManager: SensorManager
    private lateinit var windowManager: WindowManager

    private var sensor: Sensor? = null
    private var usingRawAccelerometer = false
    private var sensorsActive = false
    private var initialized = false
    private var receiverRegistered = false

    private var overlayView: View? = null
    private var lastAlpha = -1f

    private var startAngle = PrivacyPrefs.DEFAULT_START_ANGLE
    private var maxAngle = PrivacyPrefs.DEFAULT_MAX_ANGLE
    private var basePitch = 0f
    private var baseRoll = 0f

    private val gravity = FloatArray(3)
    private var gravitySeeded = false
    private var lastPitch = 0f
    private var lastRoll = 0f

    /** Pause sensing while the display is off to save battery. */
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> stopSensors()
                Intent.ACTION_SCREEN_ON -> startSensors()
            }
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Must happen promptly after startForegroundService().
        enterForeground()

        if (!initialized) initialize()
        if (initialized && intent?.action == ACTION_CALIBRATE) calibrate()

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopSensors()
        if (receiverRegistered) {
            runCatching { unregisterReceiver(screenReceiver) }
            receiverRegistered = false
        }
        runCatching { PrivacyPrefs.prefs(this).unregisterOnSharedPreferenceChangeListener(this) }
        removeOverlay()
        PrivacyPrefs.setRunning(this, false)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- setup

    private fun initialize() {
        if (!Settings.canDrawOverlays(this)) {
            fail("\"Draw over other apps\" permission is not granted.")
            return
        }

        // Prefer the fused gravity sensor; fall back to a low-pass-filtered accelerometer.
        val gravitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)
        val accelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        when {
            gravitySensor != null -> {
                sensor = gravitySensor
                usingRawAccelerometer = false
            }
            accelSensor != null -> {
                sensor = accelSensor
                usingRawAccelerometer = true
            }
            else -> {
                fail("This device has no accelerometer or gravity sensor, so tilt tracking is impossible.")
                return
            }
        }

        reloadSettings()

        if (!addOverlay()) {
            fail("Could not create the overlay window.")
            return
        }

        ContextCompat.registerReceiver(
            this,
            screenReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        receiverRegistered = true

        PrivacyPrefs.prefs(this).registerOnSharedPreferenceChangeListener(this)

        if (!startSensors()) return // startSensors() already called fail()

        PrivacyPrefs.setError(this, null)
        PrivacyPrefs.setRunning(this, true)
        initialized = true
    }

    private fun fail(message: String) {
        Log.e(TAG, message)
        PrivacyPrefs.setError(this, message)
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        stopSelf()
    }

    private fun reloadSettings() {
        startAngle = PrivacyPrefs.startAngle(this)
        maxAngle = max(PrivacyPrefs.maxAngle(this), startAngle + PrivacyPrefs.MIN_ANGLE_GAP)
        basePitch = PrivacyPrefs.basePitch(this)
        baseRoll = PrivacyPrefs.baseRoll(this)
    }

    override fun onSharedPreferenceChanged(prefs: SharedPreferences?, key: String?) {
        when (key) {
            PrivacyPrefs.KEY_START_ANGLE,
            PrivacyPrefs.KEY_MAX_ANGLE,
            PrivacyPrefs.KEY_BASE_PITCH,
            PrivacyPrefs.KEY_BASE_ROLL -> reloadSettings()
        }
    }

    private fun calibrate() {
        PrivacyPrefs.setBaseline(this, lastPitch, lastRoll)
        Toast.makeText(this, "Straight-on position saved", Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------------- sensors

    private fun startSensors(): Boolean {
        if (sensorsActive) return true
        val s = sensor ?: return false
        gravitySeeded = false
        val ok = sensorManager.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
        if (!ok) {
            fail("Failed to register the motion sensor listener.")
            return false
        }
        sensorsActive = true
        return true
    }

    private fun stopSensors() {
        if (!sensorsActive) return
        sensorManager.unregisterListener(this)
        sensorsActive = false
    }

    override fun onSensorChanged(event: SensorEvent) {
        val v = event.values
        if (usingRawAccelerometer) {
            if (!gravitySeeded) {
                v.copyInto(gravity, endIndex = 3)
                gravitySeeded = true
            } else {
                for (i in 0..2) gravity[i] = LOW_PASS * gravity[i] + (1f - LOW_PASS) * v[i]
            }
        } else {
            v.copyInto(gravity, endIndex = 3)
        }

        val gx = gravity[0]
        val gy = gravity[1]
        val gz = gravity[2]

        // Held upright in portrait: gy ~ +9.8 -> pitch 0, roll 0 ("straight look").
        // Top of phone tipping backwards (screen faces up) -> pitch increases.
        lastPitch = Math.toDegrees(atan2(gz, gy).toDouble()).toFloat()
        lastRoll = Math.toDegrees(atan2(gx, hypot(gy, gz)).toDouble()).toFloat()

        val pitchDev = abs(TiltMath.angleDelta(lastPitch, basePitch))
        val rollDev = abs(TiltMath.angleDelta(lastRoll, baseRoll))
        val tilt = max(pitchDev, rollDev)

        applyAlpha(TiltMath.alphaFor(tilt, startAngle, maxAngle))
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    // ---------------------------------------------------------------- overlay

    private fun addOverlay(): Boolean {
        val view = View(this).apply {
            setBackgroundColor(Color.BLACK)
            alpha = 0f
            visibility = View.INVISIBLE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            // Tint is driven by View.alpha instead of LayoutParams.alpha: Android 12+ blocks
            // pass-through touches for overlay windows with window-alpha above 0.8, which
            // would make the phone untouchable while blacked out.
        }

        return try {
            windowManager.addView(view, params)
            overlayView = view
            true
        } catch (e: Exception) {
            Log.e(TAG, "addView failed", e)
            false
        }
    }

    private fun removeOverlay() {
        overlayView?.let { runCatching { windowManager.removeViewImmediate(it) } }
        overlayView = null
    }

    private fun applyAlpha(alpha: Float) {
        val view = overlayView ?: return
        val changed = alpha != lastAlpha &&
            (alpha == 0f || lastAlpha <= 0f || abs(alpha - lastAlpha) >= 0.005f)
        if (!changed) return
        lastAlpha = alpha
        view.alpha = alpha
        view.visibility = if (alpha <= 0f) View.INVISIBLE else View.VISIBLE
    }

    // ---------------------------------------------------------------- notification

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Privacy Screen",
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Shown while tilt-based privacy protection is active" }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), flags
        )
        val calibrateIntent = PendingIntent.getService(
            this, 1,
            Intent(this, PrivacyOverlayService::class.java).setAction(ACTION_CALIBRATE),
            flags
        )
        val stopIntent = PendingIntent.getService(
            this, 2,
            Intent(this, PrivacyOverlayService::class.java).setAction(ACTION_STOP),
            flags
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Privacy Screen is active")
            .setContentText("Screen darkens when tilted away from you")
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, "Set straight-on", calibrateIntent)
            .addAction(0, "Stop", stopIntent)
            .build()
    }

    private fun enterForeground() {
        val notification = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
            fail("Could not start the foreground service: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "PrivacyOverlayService"
        private const val CHANNEL_ID = "privacy_screen_channel"
        private const val NOTIFICATION_ID = 1001
        private const val LOW_PASS = 0.5f // raw-accelerometer smoothing; lower = more responsive

        const val ACTION_STOP = "com.example.privacyscreen.action.STOP"
        const val ACTION_CALIBRATE = "com.example.privacyscreen.action.CALIBRATE"
    }
}
