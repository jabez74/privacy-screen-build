package com.example.privacyscreen

import android.content.Context
import android.content.SharedPreferences

/**
 * Single source of truth shared by the UI and the service.
 * The service listens to changes, so slider edits apply live to a running service.
 */
object PrivacyPrefs {
    const val KEY_START_ANGLE = "start_angle"
    const val KEY_MAX_ANGLE = "max_angle"
    const val KEY_BASE_PITCH = "base_pitch"
    const val KEY_BASE_ROLL = "base_roll"
    const val KEY_RUNNING = "service_running"
    const val KEY_ERROR = "service_error"

    const val DEFAULT_START_ANGLE = 15f
    const val DEFAULT_MAX_ANGLE = 40f
    const val MIN_ANGLE_GAP = 5f

    private const val FILE_NAME = "privacy_screen_prefs"

    fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    fun startAngle(context: Context): Float =
        prefs(context).getFloat(KEY_START_ANGLE, DEFAULT_START_ANGLE)

    fun maxAngle(context: Context): Float =
        prefs(context).getFloat(KEY_MAX_ANGLE, DEFAULT_MAX_ANGLE)

    fun basePitch(context: Context): Float = prefs(context).getFloat(KEY_BASE_PITCH, 0f)

    fun baseRoll(context: Context): Float = prefs(context).getFloat(KEY_BASE_ROLL, 0f)

    /** Saves both angles together, guaranteeing max > start by at least [MIN_ANGLE_GAP]. */
    fun setAngles(context: Context, start: Float, max: Float) {
        val safeMax = maxOf(max, start + MIN_ANGLE_GAP)
        prefs(context).edit()
            .putFloat(KEY_START_ANGLE, start)
            .putFloat(KEY_MAX_ANGLE, safeMax)
            .apply()
    }

    fun setBaseline(context: Context, pitch: Float, roll: Float) {
        prefs(context).edit()
            .putFloat(KEY_BASE_PITCH, pitch)
            .putFloat(KEY_BASE_ROLL, roll)
            .apply()
    }

    fun isRunning(context: Context): Boolean = prefs(context).getBoolean(KEY_RUNNING, false)

    fun setRunning(context: Context, running: Boolean) {
        prefs(context).edit().putBoolean(KEY_RUNNING, running).apply()
    }

    fun error(context: Context): String? = prefs(context).getString(KEY_ERROR, null)

    fun setError(context: Context, message: String?) {
        prefs(context).edit().putString(KEY_ERROR, message).apply()
    }
}
